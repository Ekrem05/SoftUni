﻿namespace Cards
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] array = Console.ReadLine().Split(", ");
            List<Card> list = new();
            for (int i = 0; i < array.Length; i++)
            {
                string[] card = array[i].Split(" ");
                string face = card[0];
                string suit = card[1];
                
                try
                {   Card card1=new(face,suit);
                   list.Add(card1);
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                }
            }
            Console.WriteLine(string.Join(" ",list));

        }
    }
}