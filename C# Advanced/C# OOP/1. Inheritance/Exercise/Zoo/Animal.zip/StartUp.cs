﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var smth = new Reptile("pesho");
        }
    }
}