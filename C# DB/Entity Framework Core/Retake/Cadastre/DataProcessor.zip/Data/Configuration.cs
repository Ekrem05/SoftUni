﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Cadastre;Trusted_Connection=True";
    }
}
