﻿namespace Cadastre.DataProcessor.ExportDtos
{
    public class ExportOwners
    {
        public string LastName { get; set; }
        public string MaritalStatus { get; set; }
    }
}