﻿using System;
using System.Collections.Generic;

namespace SoftUni.Models
{
    public partial class VEmployeesHiredAfter2000
    {
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public DateTime HireDate { get; set; }
    }
}
