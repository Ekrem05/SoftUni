﻿namespace Medicines.DataProcessor.ExportDtos
{
    public class ExportPharmacy
    {
        public string Name { get; set; }
        public string PhoneNumber{ get; set; }
    }
}