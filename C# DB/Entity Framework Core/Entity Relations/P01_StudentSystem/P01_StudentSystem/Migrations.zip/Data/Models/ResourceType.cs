﻿using System.Reflection.Metadata;

namespace P01_StudentSystem.Data.Models
{
    public enum ResourceType
    {
        Video, Presentation, Document , Other
    }
}