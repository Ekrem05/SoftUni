﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Trucks;Trusted_Connection=True";
    }
}