﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shape
{
    public abstract class Shape
    {
        public abstract double CalculatePeimeter();
        public abstract double CalculateArea();
        public virtual string Draw()
        {
            return $"Drawing Shape";
        }

    }
}
